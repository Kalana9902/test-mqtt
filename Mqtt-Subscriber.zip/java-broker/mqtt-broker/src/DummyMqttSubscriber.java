import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class DummyMqttSubscriber {
    public static void main(String[] args) {
            String broker = "tcp://localhost:1883";
        String clientId = "dummy-subscriber";
        String topic = "sensor_data";

        try {
            MqttClient mqttClient = new MqttClient(broker, clientId, new MemoryPersistence());
            MqttConnectOptions connectOptions = new MqttConnectOptions();
            connectOptions.setCleanSession(true);

            mqttClient.connect(connectOptions);

            mqttClient.subscribe(topic, (topic1, message) -> {
                String payload = new String(message.getPayload());
                System.out.println("Received: " + payload);
            });

            while (true) {
                // Keep the subscriber alive
            }

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
