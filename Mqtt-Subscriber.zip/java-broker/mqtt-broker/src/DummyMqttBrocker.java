import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class DummyMqttBrocker {
    public static void main(String[] args) {
        String broker = "tcp://localhost:1883";
        String clientId = "dummy-broker";

        try {
            MqttClient mqttClient = new MqttClient(broker, clientId);
            MqttConnectOptions connectOptions = new MqttConnectOptions();
            connectOptions.setCleanSession(true);

            mqttClient.connect(connectOptions);

            while (true) {
                // Generate dummy data
                String dummyData = generateDummyData();

                // Publish dummy data to the topic
                MqttMessage message = new MqttMessage(dummyData.getBytes());
                mqttClient.publish("sensor_data", message);

                System.out.println("Published: " + dummyData);

                // Wait for 15 seconds
                Thread.sleep(15000);
            }
        } catch (MqttException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static String generateDummyData() {
        double temperature = Math.round(Math.random() * 10 + 20);
        double humidity = Math.round(Math.random() * 20 + 40);
        return String.format("{\"temperature\": %.2f, \"humidity\": %.2f}", temperature, humidity);
    }
}
